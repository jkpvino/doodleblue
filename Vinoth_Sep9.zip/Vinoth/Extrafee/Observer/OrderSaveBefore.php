<?php

namespace Vinoth\Extrafee\Observer;

use Magento\Framework\Event\ObserverInterface;

class OrderSaveBefore implements ObserverInterface {

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;
    protected $customerSession;
    private $extraFeeModel;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $quoteobj;

    protected $_helper;

    /**
     * 
     * @param \Magento\Checkout\Model\Session $quoteobj
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        \Vinoth\Extrafee\Model\Extrafee $extraFeeModel,
        \Magento\Checkout\Model\Session $quoteobj, 
        \Vinoth\Extrafee\Helper\Data $helper,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) {
        $this->quoteobj = $quoteobj;
        $this->scopeConfig = $scopeConfig;
        $this->customerSession = $customerSession;
        $this->_helper = $helper;
        $this->extraFeeModel = $extraFeeModel;
    }

    /**
     * set extra fee to order object
     *
     * @param   \Magento\Framework\Event\Observer $observer
     * @return  $this
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    public function execute(\Magento\Framework\Event\Observer $observer) {
		

        $order = $observer->getEvent()->getOrder();
        $quote = $this->quoteobj->getQuote();
        $baseExtraFee = $extraFee = $this->_helper->getSubFee();

        /*$orderIds = $observer->getEvent()->getOrderIds();
        $lastorderId = $orderIds[0];
        $this->extraFeeModel->setOrderId($lastorderId);
        $this->extraFeeModel->setFee($extraFee);
        $this->extraFeeModel->save();*/

		
        if ($extraFee) {
            $order->setFee($extraFee);
        }
        if ($baseExtraFee) {
            $order->setBaseFee($baseExtraFee);
        }
        return $this;
    }

}
