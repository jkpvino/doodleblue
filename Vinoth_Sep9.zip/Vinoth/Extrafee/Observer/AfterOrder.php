<?php

namespace Vinoth\Extrafee\Observer;

use Magento\Framework\Event\ObserverInterface;

class AfterOrder implements ObserverInterface
{
    //private $orderFacory;

    private $extraFeeModel;

    private $helper;

    protected $_order;

    public function __construct(
    	\Vinoth\Extrafee\Model\Extrafee $extraFeeModel,
    	\Vinoth\Extrafee\Helper\Data $helper,
    	\Magento\Quote\Model\QuoteFactory $quoteFactory,
        \Magento\Sales\Api\Data\OrderInterface $order
    ) {
    	$this->extraFeeModel = $extraFeeModel;
        $this->helper = $helper;
        $this->_order = $order;    
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $orderIds = $observer->getEvent()->getOrderIds();
        $lastorderId = $orderIds[0];
        $order = $this->_order->load($lastorderId);
        $extraFee = $order->getFee() ? $order->getFee() : 0;
        $this->extraFeeModel->setOrderId($lastorderId);
        $this->extraFeeModel->setFee($extraFee);
        $this->extraFeeModel->save();
    }
}
