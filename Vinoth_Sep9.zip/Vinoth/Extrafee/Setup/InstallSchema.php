<?php


namespace Vinoth\Extrafee\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;

class InstallSchema implements InstallSchemaInterface
{

    /**
     * {@inheritdoc}
     */
    public function install(
        SchemaSetupInterface $setup,
        ModuleContextInterface $context
    ) {
        $installer = $setup;
        $installer->startSetup();

        $table_vinoth_extrafee = $setup->getConnection()->newTable($setup->getTable('vinoth_extrafee'));

        $table_vinoth_extrafee->addColumn(
            'extrafee_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            [
                'identity' => true,
                'nullable' => false,
                'primary' => true,
                'unsigned' => true,
            ],
            'Entity ID'
        );

        $table_vinoth_extrafee->addColumn(
            'order_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            [],
            'order_id'
        );

        $table_vinoth_extrafee->addColumn(
            'fee',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            [],
            'fee'
        );
        
        $setup->getConnection()->createTable($table_vinoth_extrafee);
        $setup->endSetup();

        $columns = [
            'fee' => [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                'length' => '12,4',
                'nullable' => true,
                'comment' => 'COD Payment',
            ],
        ];
        $basecolumns = [
            'base_fee' => [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                'length' => '12,4',
                'nullable' => true,
                'comment' => 'Base COD Payment',
            ],
        ];
        $salesTable = $installer->getTable('sales_order');
        $salesAddressTable = $installer->getTable('sales_order_address');
        $invoiceTable = $installer->getTable('sales_invoice');
        $creditmemoTable = $installer->getTable('sales_creditmemo');
        $quoteTable = $installer->getTable('quote');
        $quoteAddressTable = $installer->getTable('quote_address');
        $tableList = array($salesTable, $salesAddressTable, $invoiceTable, $creditmemoTable, $quoteTable, $quoteAddressTable);

        $connection = $installer->getConnection();
        foreach ($columns as $name => $definition) {
            for ($count = 0; $count < count($tableList); $count++) {
                $connection->addColumn($tableList[$count], $name, $definition);
            }
        }
        foreach ($basecolumns as $name => $definition) {
            for ($count = 0; $count < count($tableList); $count++) {
                $connection->addColumn($tableList[$count], $name, $definition);
            }
        }

        $installer->endSetup();

    }
}
