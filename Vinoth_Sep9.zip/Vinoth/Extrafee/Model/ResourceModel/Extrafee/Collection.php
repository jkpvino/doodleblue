<?php

namespace Vinoth\Extrafee\Model\ResourceModel\Extrafee;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Contact Resource Model Collection
 *
 * @author      Pierre FAY
 */
class Collection extends AbstractCollection
{
    /**
     * Initialize resource collection
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('Vinoth\Extrafee\Model\Extrafee', 'Vinoth\Extrafee\Model\ResourceModel\Extrafee');
    }
}