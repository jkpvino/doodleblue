<?php

namespace Vinoth\Extrafee\Model;

use Magento\Framework\Model\AbstractModel;

class Extrafee extends AbstractModel
{
    protected function _construct()
    {
        $this->_init('Vinoth\Extrafee\Model\ResourceModel\Extrafee');
    }
}
