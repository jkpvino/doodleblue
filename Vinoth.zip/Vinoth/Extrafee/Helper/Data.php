<?php

namespace Vinoth\Extrafee\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * ScopeConfig
     *
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopInterface
     */
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeInterface
    ) {
        $this->_scopeConfig = $scopeInterface;
    }

    public function getTitle()
    {
        return $this->_scopeConfig->getValue(
            'customfee/general/title', 
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getExtraFee()
    {
        /*return $this->_scopeConfig->getValue(
            'customfee/general/price',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );*/
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $cart = $objectManager->get('\Magento\Checkout\Model\Cart');

        $subTotal = $cart->getQuote()->getSubtotal();
        $grandTotal = $cart->getQuote()->getGrandTotal();

        $limit = $no = $this->_scopeConfig->getValue(
            'customfee/general/price',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );

        $limit = $limit <= 0 ? $limit : -$limit ;

        if($grandTotal > $no){
            return $limit;
        }else{
            return 0;
        }

        

    }

    public function getSubFee()
    {
        /*return $this->_scopeConfig->getValue(
            'customfee/general/price',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );*/
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $cart = $objectManager->get('\Magento\Checkout\Model\Cart');

        $subTotal = $cart->getQuote()->getSubtotal();
        $grandTotal = $cart->getQuote()->getGrandTotal();

        $limit = $this->_scopeConfig->getValue(
            'customfee/general/price',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        if($grandTotal > $limit){
            return $limit;
        }else{
            return 0;
        }

        

    }
}